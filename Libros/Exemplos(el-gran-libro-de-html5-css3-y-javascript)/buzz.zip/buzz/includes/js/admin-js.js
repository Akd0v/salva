jQuery(document).ready(function(){ 
    jQuery( "#rt_tabs" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
    jQuery( "#rt_tabs li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );  
});