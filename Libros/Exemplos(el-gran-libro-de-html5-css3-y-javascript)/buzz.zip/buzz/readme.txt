=== discover ===
Theme URI: http://freethemesnow.net/buzz-corporate-responsive-theme/
Author: freethemesnow.net
Author URI: http://freethemesnow.net/
Description: A very simple flat and free theme for WordPress. The theme is fully responsive that looks great on any mobile device. Perfect to use as business theme. With features theme-options, threaded-comments and multi-level dropdown menu. Notice: this template working great with Wordpress 3.5 and Wordpress 3.6. If you using early version, please update your Wordpress engine!
Buzz, 2013 freethemesnow.net


== Description ==
Professional corporate responsive theme.


== Installation ==
You can install the theme through the WordPress installer under Themes-Install themes by searching for it.
Alternatively you can download the file from here, unzip it and move the unzipped contents to the wp-content/themes folder
of your WordPress installation. You will then be able to activate the theme.


== Instruction ==
You can using theme settings page in admin side to setting up our theme.


== Change log ==
1.0.2
Fix checkboxes, selects and text domains

1.0.1
Copyrights

Thanks for downloading the Buzz theme.