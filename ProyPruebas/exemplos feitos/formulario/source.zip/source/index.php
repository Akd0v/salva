<?php
/**
 * Mailchimp form
 *
 * @author Marc Oliveras Galvez <oligalma@gmail.com> 
 * @link http://www.oligalma.com
 * @copyright 2016 Oligalma
 * @license GPL
 */

define('API_KEY','f39d7386de24cdaaaadf6503ecd203d0-us12');
define('LIST_ID', 'cdbaaab68c');
define('SHOW_NAME', true);

if(isset($_POST['subscribe-submit']))
{
    if(!empty($_POST['subscribe-email']) && (!SHOW_NAME || (!empty($_POST['subscribe-first-name']) && !empty($_POST['subscribe-last-name']))))
    {                
	require 'lib/Mailchimp.php';
	
	$email = array('email' => $_POST['subscribe-email']);

	if(SHOW_NAME)
	    $merge_vars = array('FNAME' => $_POST['subscribe-first-name'],'LNAME' => $_POST['subscribe-last-name']);
	else
	    $merge_vars = array();
	
	$email_type = 'html';
	$double_optin = true;
	
	$Mailchimp = new Mailchimp(API_KEY);
	$Mailchimp_Lists = new Mailchimp_Lists($Mailchimp);
	
	try
	{
	    $subscriber = $Mailchimp_Lists->subscribe(LIST_ID, $email, $merge_vars, $email_type, $double_optin);
	}
	catch(Exception $e)
	{
	    $message = '<span class="subscribe-red">' . $e->getMessage() . '</span>';   
	}
	
	if (!empty($subscriber['leid'])) {
	    $message = '<span class="subscribe-green">You have been subscribed successfully.</span>';
	}
    }
    else
    {
	$message = '<span class="subscribe-red">You need to fill all fields.</span>';   
    }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
       <div id="subscribe-div">
	  <?php
	  if(isset($message))
	      echo '<div id="subscribe-message">' . $message . '</div>';
	  ?>
	   <form method="POST">  
	      <span class="subscribe-label">Email</span>
	      <input type="email" id="subscribe-email" name="subscribe-email" value="<?= (empty($_POST['subscribe-email']) ? '' : $_POST['subscribe-email']) ?>" required />
	      <?php
		if(SHOW_NAME):
	      ?>
		    <span class="subscribe-label">First name</span>
		    <input type="text" id="subscribe-first-name" name="subscribe-first-name" value="<?= (empty($_POST['subscribe-first-name']) ? '' : $_POST['subscribe-first-name']) ?>" required />
		    <span class="subscribe-label">Last name</span>
		    <input type="text" id="subscribe-last-name" name="subscribe-last-name" value="<?= (empty($_POST['subscribe-last-name']) ? '' : $_POST['subscribe-last-name']) ?>" required />
	      <?php
		endif;
	      ?>
	      <input type="submit" id="subscribe-submit" name="subscribe-submit" value="SUBSCRIBE" />
	  </form>
      </div>
  </body>
</html>